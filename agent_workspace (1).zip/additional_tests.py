import requests
import json
import time

# API endpoint
url = "http://127.0.0.1:5000/chat"

def test_predictions():
    print("Additional API Testing")
    print("=====================")
    
    # Test multiple sports predictions to check randomness
    print("\n1. Testing Sports Prediction Randomness (5 requests):")
    for i in range(5):
        response = requests.post(url, json={"message": "sports prediction"})
        print(f"Response {i+1}: {response.json()['response']}")
        time.sleep(0.1)
    
    # Test case variations
    print("\n2. Testing Case Variations:")
    test_cases = [
        {"message": "SPORT", "expected_category": "sports"},
        {"message": "Crypto", "expected_category": "crypto"},
        {"message": "FOREX analysis", "expected_category": "forex"},
        {"message": "Security update", "expected_category": "cybersecurity"},
    ]
    
    for case in test_cases:
        response = requests.post(url, json=case)
        result = response.json()
        print(f"Input: '{case['message']}' -> Response: {result['response']}")
    
    # Test edge cases
    print("\n3. Testing Edge Cases:")
    edge_cases = [
        {"message": ""},  # Empty message
        {"message": "   "},  # Whitespace only
        {},  # No message field
        {"message": "random text"},  # Unrecognized category
    ]
    
    for i, case in enumerate(edge_cases):
        try:
            response = requests.post(url, json=case)
            result = response.json()
            print(f"Edge case {i+1}: {case} -> {result['response']}")
        except Exception as e:
            print(f"Edge case {i+1}: {case} -> Error: {e}")
    
    # Test multiple category keywords in one message
    print("\n4. Testing Multiple Keywords:")
    multi_keyword_cases = [
        "I want sports and forex predictions",
        "crypto security analysis",
        "forex and crypto market update"
    ]
    
    for case in multi_keyword_cases:
        response = requests.post(url, json={"message": case})
        result = response.json()
        print(f"'{case}' -> {result['response']}")

if __name__ == "__main__":
    test_predictions()
