# Deploy to Railway - Free Hosting
import os
import json

# Railway deployment configuration
railway_config = {
    "name": "ai-prediction-app",
    "services": {
        "web": {
            "build": {
                "builder": "NIXPACKS"
            },
            "deploy": {
                "startCommand": "gunicorn prediction_api:app",
                "healthcheckPath": "/",
                "healthcheckTimeout": 300,
                "restartPolicyType": "ON_FAILURE"
            }
        }
    }
}

# Save Railway config
with open('railway.json', 'w') as f:
    json.dump(railway_config, f, indent=2)

print("✅ Railway configuration created!")
print("🚀 Your app will be deployed at: https://your-app-name.up.railway.app")
