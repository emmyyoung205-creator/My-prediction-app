#!/bin/bash

echo "🚀 AI Prediction App Demo"
echo "========================="

# Wait for server to be ready
sleep 2

echo -e "\n📱 Your app is running at: http://127.0.0.1:5000"
echo -e "\n✨ Features available:"
echo "  🌐 Beautiful Web Interface"
echo "  📱 Mobile-ready (installable as app)"
echo "  🔮 4 Prediction Categories:"
echo "    • Sports Predictions"
echo "    • Forex Trading"
echo "    • Cryptocurrency"
echo "    • Cybersecurity"

echo -e "\n🧪 Testing API directly:"

# Test each category
echo -e "\n1. 🏈 Sports Prediction:"
curl -s -X POST -H "Content-Type: application/json" \
     -d '{"message": "sports prediction"}' \
     http://127.0.0.1:5000/chat | python -m json.tool

echo -e "\n2. 💱 Forex Prediction:"
curl -s -X POST -H "Content-Type: application/json" \
     -d '{"message": "forex market"}' \
     http://127.0.0.1:5000/chat | python -m json.tool

echo -e "\n3. ₿ Crypto Prediction:"
curl -s -X POST -H "Content-Type: application/json" \
     -d '{"message": "crypto analysis"}' \
     http://127.0.0.1:5000/chat | python -m json.tool

echo -e "\n4. 🔒 Security Prediction:"
curl -s -X POST -H "Content-Type: application/json" \
     -d '{"message": "security threats"}' \
     http://127.0.0.1:5000/chat | python -m json.tool

echo -e "\n🌟 How to use:"
echo "  1. Open http://127.0.0.1:5000 in your browser"
echo "  2. Click category buttons or type questions"
echo "  3. Get instant AI predictions!"

echo -e "\n📱 Mobile Install:"
echo "  • iOS: Safari → Share → Add to Home Screen"
echo "  • Android: Chrome → Menu → Add to Home Screen"

echo -e "\n🚀 Ready to deploy? Check DEPLOYMENT_GUIDE.md"
echo -e "\n🎉 Your API is now a complete app!"
