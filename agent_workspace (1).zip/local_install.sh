#!/bin/bash

# AI Prediction App - Local Installation Script
echo "🚀 Installing AI Prediction App Locally..."

# Create project directory
mkdir -p ai-prediction-app
cd ai-prediction-app

# Create directories
mkdir -p templates static

echo "📁 Created project structure"

# You'll need to copy these files manually:
echo "📋 Required files to copy:"
echo "  ✅ prediction_api.py (main Flask app)"
echo "  ✅ templates/index.html (web interface)"
echo "  ✅ static/manifest.json (PWA manifest)"
echo "  ✅ static/sw.js (service worker)"
echo "  ✅ requirements.txt (dependencies)"

echo ""
echo "🔧 After copying files, run:"
echo "  pip install -r requirements.txt"
echo "  python prediction_api.py"

echo ""
echo "🌐 Then visit: http://localhost:5000"
