#!/bin/bash
echo "🚀 Installing AI Prediction App..."
echo "================================="

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required. Please install Python from https://python.org"
    exit 1
fi

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip is required. Please install pip"
    exit 1
fi

# Install Flask
echo "📦 Installing Flask..."
pip3 install Flask

# Run the app
echo "🚀 Starting AI Prediction App..."
echo "📱 Your app will be available at: http://localhost:5000"
echo "🌟 Press Ctrl+C to stop the app"
echo ""
python3 prediction_api.py
