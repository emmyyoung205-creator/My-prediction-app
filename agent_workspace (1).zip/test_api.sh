#!/bin/bash

echo "Testing Flask Prediction API"
echo "============================="

# Test sports prediction
echo -e "\n1. Testing Sports Prediction:"
curl -X POST -H "Content-Type: application/json" \
     -d '{"message": "What about sports today?"}' \
     http://127.0.0.1:5000/chat

# Test forex prediction
echo -e "\n\n2. Testing Forex Prediction:"
curl -X POST -H "Content-Type: application/json" \
     -d '{"message": "Any forex recommendations?"}' \
     http://127.0.0.1:5000/chat

# Test crypto prediction
echo -e "\n\n3. Testing Crypto Prediction:"
curl -X POST -H "Content-Type: application/json" \
     -d '{"message": "How about crypto market?"}' \
     http://127.0.0.1:5000/chat

# Test cybersecurity prediction
echo -e "\n\n4. Testing Cybersecurity Prediction:"
curl -X POST -H "Content-Type: application/json" \
     -d '{"message": "Any security threats today?"}' \
     http://127.0.0.1:5000/chat

# Test unknown category
echo -e "\n\n5. Testing Unknown Category:"
curl -X POST -H "Content-Type: application/json" \
     -d '{"message": "What about weather prediction?"}' \
     http://127.0.0.1:5000/chat

echo -e "\n\nAPI Testing Complete!"
