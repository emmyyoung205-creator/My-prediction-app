#!/bin/bash

echo "📦 Creating Complete App Package..."
echo "=================================="

# Create package directory
mkdir -p complete_app_package
cd complete_app_package

# Create necessary directories
mkdir -p templates static

# Copy all files
cp ../prediction_api.py .
cp ../requirements.txt .
cp ../templates/index.html templates/
cp ../static/manifest.json static/
cp ../static/sw.js static/

# Create simple installer
cat > install_and_run.sh << 'EOF'
#!/bin/bash
echo "🚀 Installing AI Prediction App..."
echo "================================="

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required. Please install Python from https://python.org"
    exit 1
fi

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip is required. Please install pip"
    exit 1
fi

# Install Flask
echo "📦 Installing Flask..."
pip3 install Flask

# Run the app
echo "🚀 Starting AI Prediction App..."
echo "📱 Your app will be available at: http://localhost:5000"
echo "🌟 Press Ctrl+C to stop the app"
echo ""
python3 prediction_api.py
EOF

# Create Windows installer
cat > install_and_run.bat << 'EOF'
@echo off
echo 🚀 Installing AI Prediction App...
echo ==================================

REM Check if Python is installed
python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo ❌ Python is required. Please install Python from https://python.org
    pause
    exit /b 1
)

REM Install Flask
echo 📦 Installing Flask...
pip install Flask

REM Run the app
echo 🚀 Starting AI Prediction App...
echo 📱 Your app will be available at: http://localhost:5000
echo 🌟 Press Ctrl+C to stop the app
echo.
python prediction_api.py
pause
EOF

# Make scripts executable
chmod +x install_and_run.sh

# Create README
cat > README.md << 'EOF'
# 🚀 AI Prediction App - Ready to Install!

## ⚡ SUPER QUICK INSTALL:

### 🖥️ **Windows Users:**
1. Double-click `install_and_run.bat`
2. Wait for installation
3. App opens at http://localhost:5000

### 🍎 **Mac/Linux Users:**
1. Open Terminal in this folder
2. Run: `bash install_and_run.sh`
3. App opens at http://localhost:5000

## 📱 **Install as Mobile App:**

### iPhone/iPad:
1. Open Safari → http://localhost:5000
2. Tap Share → "Add to Home Screen"

### Android:
1. Open Chrome → http://localhost:5000
2. Tap Menu → "Add to Home Screen"

## 🌐 **Deploy Online:**

### Heroku (Free):
```bash
git init
git add .
git commit -m "Deploy app"
heroku create your-app-name
git push heroku main
```

### Railway:
1. Visit railway.app
2. Connect GitHub and upload files
3. Auto-deploy!

## ✨ **Features:**
- 🏈 Sports Predictions
- 💱 Forex Trading Tips  
- ₿ Crypto Analysis
- 🔒 Security Alerts
- 📱 Mobile App Support
- 🌐 Web Interface

**Enjoy your AI Prediction App!** 🎉
EOF

echo ""
echo "✅ Package created successfully!"
echo "📁 Location: $(pwd)"
echo ""
echo "📋 Package contains:"
echo "  ✅ prediction_api.py - Main Flask app"
echo "  ✅ templates/index.html - Web interface"
echo "  ✅ static/ - Mobile app files"
echo "  ✅ requirements.txt - Dependencies"
echo "  ✅ install_and_run.sh - Auto installer (Mac/Linux)"
echo "  ✅ install_and_run.bat - Auto installer (Windows)"
echo "  ✅ README.md - Instructions"
echo ""
echo "🚀 To install: Copy this folder to your computer and run the installer!"
