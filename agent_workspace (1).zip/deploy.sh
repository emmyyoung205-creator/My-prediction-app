#!/bin/bash

echo "🚀 AI Prediction App - Auto Deployment Script"
echo "=============================================="

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo "❌ Git is required. Please install Git first."
    exit 1
fi

echo ""
echo "📋 Available Deployment Options:"
echo "1. 🚂 Railway (Fastest - 2 minutes)"
echo "2. 🔥 Heroku (Most popular - 5 minutes)"
echo "3. ⚡ Vercel (Frontend-focused - 3 minutes)"
echo "4. 🎨 Render (Full-stack - 4 minutes)"
echo ""
read -p "Choose deployment option (1-4): " choice

case $choice in
    1)
        echo ""
        echo "🚂 Deploying to Railway..."
        echo "========================="
        echo "1. Visit: https://railway.app"
        echo "2. Sign up with GitHub"
        echo "3. Click 'Deploy from GitHub repo'"
        echo "4. Upload your project files"
        echo "5. Your app will be live automatically!"
        echo ""
        echo "📁 Files to upload:"
        ls -la *.py *.txt *.json Procfile templates/ static/ 2>/dev/null
        ;;
    2)
        echo ""
        echo "🔥 Deploying to Heroku..."
        echo "========================"
        
        # Check if heroku CLI is installed
        if ! command -v heroku &> /dev/null; then
            echo "⚠️  Heroku CLI not found. Installing..."
            echo "Please install from: https://devcenter.heroku.com/articles/heroku-cli"
            echo ""
            echo "Manual deployment steps:"
            echo "1. Install Heroku CLI"
            echo "2. Run: heroku login"
            echo "3. Run the commands below:"
        fi
        
        echo ""
        echo "📋 Heroku deployment commands:"
        echo "git init"
        echo "git add ."
        echo "git commit -m 'Deploy AI Prediction App'"
        echo "heroku create your-app-name"
        echo "git push heroku main"
        echo ""
        echo "🎯 Your app will be live at: https://your-app-name.herokuapp.com"
        ;;
    3)
        echo ""
        echo "⚡ Deploying to Vercel..."
        echo "========================"
        echo "1. Visit: https://vercel.com"
        echo "2. Sign up with GitHub"
        echo "3. Import your GitHub repository"
        echo "4. Click 'Deploy'"
        echo ""
        echo "📁 Make sure you have: vercel.json (✅ included)"
        echo "🎯 Your app will be live at: https://your-app-name.vercel.app"
        ;;
    4)
        echo ""
        echo "🎨 Deploying to Render..."
        echo "========================="
        echo "1. Visit: https://render.com"
        echo "2. Sign up with GitHub"
        echo "3. Create 'Web Service'"
        echo "4. Configure:"
        echo "   - Build Command: pip install -r requirements.txt"
        echo "   - Start Command: gunicorn prediction_api:app"
        echo ""
        echo "🎯 Your app will be live at: https://your-app-name.onrender.com"
        ;;
    *)
        echo "❌ Invalid option. Please run the script again."
        exit 1
        ;;
esac

echo ""
echo "📱 After deployment - Install as Mobile App:"
echo "==========================================="
echo "📱 iPhone/iPad:"
echo "   1. Open Safari → Visit your app URL"
echo "   2. Tap Share → 'Add to Home Screen'"
echo ""
echo "📱 Android:"
echo "   1. Open Chrome → Visit your app URL"
echo "   2. Tap 'Install App' banner"
echo ""
echo "💻 Desktop:"
echo "   1. Open Chrome → Visit your app URL"
echo "   2. Click install icon in address bar"
echo ""
echo "🎉 Your Flask API is now a live website AND mobile app!"
echo ""
echo "📋 What you'll have:"
echo "✅ Live website accessible worldwide"
echo "✅ Mobile app (installable on phones/tablets)"
echo "✅ Desktop app (installable on computers)"
echo "✅ API endpoint for programmatic access"
echo ""
echo "🚀 Happy deploying!"
