from flask import Flask, request, jsonify, render_template, send_from_directory
import random
import os

app = Flask(__name__)

# Dummy prediction functions
def predict_sports():
    return random.choice(["Team A will win", "Team B has better odds", "Draw likely"])

def predict_forex():
    return random.choice(["Buy EUR/USD", "Sell GBP/USD", "Hold USD/JPY"])

def predict_crypto():
    return random.choice(["Bitcoin bullish", "Ethereum correction coming", "Altcoins rally"])

def predict_cybersecurity():
    return random.choice(["Phishing spike detected", "No major threats", "Ransomware alert"])

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.json.get("message", "").lower()

    if "sport" in user_input:
        response = predict_sports()
    elif "forex" in user_input:
        response = predict_forex()
    elif "crypto" in user_input:
        response = predict_crypto()
    elif "security" in user_input:
        response = predict_cybersecurity()
    else:
        response = "Sorry, I can't predict that yet. Try asking about sports, forex, crypto, or cybersecurity."

    return jsonify({"response": response})

# Health check endpoint for deployment platforms
@app.route('/health')
def health_check():
    return jsonify({"status": "healthy", "service": "AI Prediction App"})

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(debug=False, host='0.0.0.0', port=port)