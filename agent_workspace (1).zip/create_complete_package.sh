#!/bin/bash

echo "📦 Creating COMPLETE Website & Mobile App Package..."
echo "=================================================="

# Create comprehensive package directory
mkdir -p website_and_mobile_app_package
cd website_and_mobile_app_package

# Create necessary directories
mkdir -p templates static

# Copy all application files
cp ../prediction_api.py .
cp ../requirements.txt .
cp ../Procfile .
cp ../vercel.json .
cp ../templates/index.html templates/
cp ../static/manifest.json static/
cp ../static/sw.js static/

# Create additional deployment files
cat > railway.toml << 'EOF'
[build]
builder = "nixpacks"

[deploy]
startCommand = "gunicorn prediction_api:app"
healthcheckPath = "/"
healthcheckTimeout = 300
restartPolicyType = "ON_FAILURE"
EOF

cat > render.yaml << 'EOF'
services:
  - type: web
    name: ai-prediction-app
    env: python
    buildCommand: pip install -r requirements.txt
    startCommand: gunicorn prediction_api:app
    envVars:
      - key: PYTHON_VERSION
        value: 3.9.10
EOF

cat > netlify.toml << 'EOF'
[build]
  command = "pip install -r requirements.txt"
  publish = "."

[[redirects]]
  from = "/*"
  to = "/prediction_api.py"
  status = 200
EOF

# Create one-click deployment scripts
cat > deploy_railway.sh << 'EOF'
#!/bin/bash
echo "🚂 Railway Deployment Instructions"
echo "================================="
echo "1. Visit: https://railway.app"
echo "2. Sign up with GitHub"
echo "3. Click 'Deploy from GitHub repo'"
echo "4. Upload this entire folder"
echo "5. Railway will auto-detect and deploy!"
echo ""
echo "🎯 Your app will be live at: https://your-app-name.up.railway.app"
echo "📱 Users can install it as mobile app from the website!"
EOF

cat > deploy_heroku.sh << 'EOF'
#!/bin/bash
echo "🔥 Heroku Deployment Commands"
echo "============================"
echo "Run these commands in this folder:"
echo ""
echo "git init"
echo "git add ."
echo "git commit -m 'Deploy AI Prediction App'"
echo "heroku create your-unique-app-name"
echo "git push heroku main"
echo ""
echo "🎯 Your app will be live at: https://your-app-name.herokuapp.com"
echo "📱 Users can install it as mobile app from the website!"
EOF

cat > deploy_vercel.sh << 'EOF'
#!/bin/bash
echo "⚡ Vercel Deployment Instructions"
echo "================================"
echo "1. Visit: https://vercel.com"
echo "2. Sign up with GitHub"
echo "3. Import your GitHub repository with these files"
echo "4. Vercel will auto-deploy!"
echo ""
echo "🎯 Your app will be live at: https://your-app-name.vercel.app"
echo "📱 Users can install it as mobile app from the website!"
EOF

# Make deployment scripts executable
chmod +x deploy_*.sh

# Create comprehensive README
cat > README.md << 'EOF'
# 🚀 AI Prediction App - Website & Mobile App Package

## 🎯 **WHAT YOU GET:**
✅ **Live Website** - Accessible worldwide at your custom URL  
✅ **Mobile App** - Installable on phones & tablets (PWA)  
✅ **Desktop App** - Installable on computers  
✅ **API Service** - Programmable interface  

---

## ⚡ **SUPER QUICK DEPLOYMENT (Choose One):**

### 🥇 **Railway (EASIEST - 2 minutes):**
1. Run: `./deploy_railway.sh` for instructions
2. Or visit: https://railway.app → Upload this folder
3. **DONE!** Your app is live!

### 🥈 **Heroku (POPULAR - 5 minutes):**
1. Install Heroku CLI: https://devcenter.heroku.com/articles/heroku-cli
2. Run: `./deploy_heroku.sh` for commands
3. **DONE!** Your app is live!

### 🥉 **Vercel (FAST - 3 minutes):**
1. Run: `./deploy_vercel.sh` for instructions
2. Or visit: https://vercel.com → Import repository
3. **DONE!** Your app is live!

---

## 📱 **INSTALL AS MOBILE APP:**

After deployment, users can install your app:

### **📱 iPhone/iPad:**
1. Open Safari → Visit your app URL
2. Tap Share → "Add to Home Screen"
3. App appears on home screen!

### **📱 Android:**
1. Open Chrome → Visit your app URL  
2. Tap "Install App" banner
3. App appears on home screen!

### **💻 Desktop:**
1. Open Chrome/Edge → Visit your app URL
2. Click install icon in address bar
3. App opens in its own window!

---

## 🎯 **APP FEATURES:**

✅ **4 Prediction Categories:**
- 🏈 Sports Predictions
- 💱 Forex Trading Tips
- ₿ Crypto Analysis  
- 🔒 Security Alerts

✅ **Modern Interface:**
- Beautiful gradient design
- Responsive layout
- Interactive animations
- Mobile-optimized

✅ **Progressive Web App (PWA):**
- Offline support
- App icons
- Splash screen
- Push notifications ready
- App shortcuts

---

## 📁 **PACKAGE CONTENTS:**

- `prediction_api.py` - Main Flask application
- `templates/index.html` - Web interface
- `static/manifest.json` - Mobile app configuration
- `static/sw.js` - Service worker for PWA features
- `requirements.txt` - Python dependencies
- `Procfile` - Heroku deployment config
- `vercel.json` - Vercel deployment config
- `railway.toml` - Railway deployment config
- `render.yaml` - Render deployment config
- `deploy_*.sh` - One-click deployment scripts

---

## 🌟 **LIVE EXAMPLES:**

Once deployed, your app URLs will look like:
- **Railway:** `https://your-app-name.up.railway.app`
- **Heroku:** `https://your-app-name.herokuapp.com`
- **Vercel:** `https://your-app-name.vercel.app`
- **Render:** `https://your-app-name.onrender.com`

---

## 🔧 **LOCAL TESTING:**

Before deployment, test locally:
```bash
pip install -r requirements.txt
python prediction_api.py
# Visit: http://localhost:5000
```

---

## 🎉 **SUCCESS!**

Your Flask API is now a complete application that works as:
- ✅ **Website** - Accessible from any browser
- ✅ **Mobile App** - Installable on phones/tablets  
- ✅ **Desktop App** - Installable on computers
- ✅ **API** - Programmable interface

**Choose your deployment method and go live in minutes!** 🚀

---

## 🛠️ **SUPPORT:**

- **Deployment Issues:** Check platform documentation
- **App Features:** Modify `prediction_api.py`
- **Styling:** Edit `templates/index.html` CSS
- **Mobile Features:** Update `static/manifest.json`

**Happy deploying!** 🎯
EOF

echo ""
echo "✅ Complete Website & Mobile App Package Created!"
echo "📁 Location: $(pwd)"
echo ""
echo "📋 Package includes:"
echo "  ✅ Flask web application"
echo "  ✅ Beautiful mobile-responsive interface" 
echo "  ✅ Progressive Web App (PWA) features"
echo "  ✅ Multiple deployment configurations"
echo "  ✅ One-click deployment scripts"
echo "  ✅ Comprehensive documentation"
echo ""
echo "🚀 Ready for deployment to:"
echo "  🚂 Railway (recommended)"
echo "  🔥 Heroku"
echo "  ⚡ Vercel"
echo "  🎨 Render"
echo ""
echo "📱 Users will be able to:"
echo "  🌐 Access your website from anywhere"
echo "  📱 Install as mobile app on phones/tablets"
echo "  💻 Install as desktop app on computers"
echo "  🔗 Use API programmatically"
echo ""
echo "🎯 Next step: Choose a deployment method and go live!"
